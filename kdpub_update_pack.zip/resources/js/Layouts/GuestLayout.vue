<script setup>
import { computed } from 'vue';
import { Link, usePage } from '@inertiajs/vue3';

const page = usePage();
const theme = computed(() => page.props.theme || {});
</script>

<template>
    <div class="min-h-screen bg-[#070c18] flex flex-col justify-center relative overflow-hidden selection:bg-rose-500 selection:text-white font-sans">
        <!-- Ambient Radial Glow Effects -->
        <div class="absolute -top-40 -left-40 w-96 h-96 bg-indigo-600/20 rounded-full blur-3xl pointer-events-none"></div>
        <div class="absolute -bottom-40 -right-40 w-96 h-96 bg-rose-600/15 rounded-full blur-3xl pointer-events-none"></div>
        <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-blue-900/10 rounded-full blur-3xl pointer-events-none"></div>

        <!-- Subtle Grid Pattern Background -->
        <div class="absolute inset-0 bg-[linear-gradient(to_right,#ffffff05_1px,transparent_1px),linear-gradient(to_bottom,#ffffff05_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] pointer-events-none"></div>

        <!-- Navigation Header / Back to site -->
        <header class="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex items-center justify-between">
            <Link href="/" class="flex items-center gap-3 group">
                <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 via-blue-600 to-rose-600 p-0.5 shadow-lg shadow-indigo-500/20 group-hover:scale-105 transition duration-300">
                    <div class="w-full h-full bg-[#0a101f] rounded-[10px] flex items-center justify-center font-black text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-rose-300 text-sm tracking-wider">
                        KD
                    </div>
                </div>
                <div>
                    <span class="font-extrabold text-lg text-white tracking-tight flex items-center gap-1.5">
                        Knowledge Dynamics
                        <span class="px-1.5 py-0.5 text-[10px] font-bold bg-indigo-500/20 text-indigo-300 rounded border border-indigo-500/30">
                            Scholar
                        </span>
                    </span>
                    <span class="block text-[10px] text-slate-400 tracking-wider uppercase font-semibold">
                        Open Access Publishing & Research
                    </span>
                </div>
            </Link>

            <Link
                href="/"
                class="inline-flex items-center gap-2 text-xs font-semibold text-slate-400 hover:text-white bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 px-3.5 py-2 rounded-xl transition backdrop-blur-sm"
            >
                <span>←</span> Back to Public Portal
            </Link>
        </header>

        <!-- Main Content Area: Split View for Desktop, Responsive Stack for Mobile -->
        <main class="relative z-10 flex-1 flex items-center justify-center py-8 px-4 sm:px-6 lg:px-8">
            <div class="w-full max-w-5xl mx-auto grid lg:grid-cols-12 gap-8 lg:gap-12 items-center">
                <!-- Left Column: Academic SaaS Pitch & Highlights (Hidden on small mobile if needed, or compact) -->
                <div class="hidden lg:flex lg:col-span-5 flex-col justify-center space-y-6 text-slate-300 pr-4">
                    <div class="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-gradient-to-r from-indigo-500/10 to-rose-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-semibold w-fit">
                        <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                        Unified Academic Portal & Webmail
                    </div>

                    <h2 class="text-3xl font-extrabold text-white tracking-tight leading-tight">
                        Elevating Global <br />
                        <span class="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-indigo-300 to-rose-400">
                            Research & Discovery
                        </span>
                    </h2>

                    <p class="text-xs text-slate-400 leading-relaxed">
                        Access your double-blind peer review queue, track manuscript production, manage Crossref DOIs, and access your official institutional cPanel Webmail in one unified cockpit.
                    </p>

                    <!-- Feature Badges List -->
                    <div class="space-y-3 pt-2">
                        <div class="flex items-center gap-3 p-2.5 rounded-xl bg-slate-900/60 border border-slate-800/80 backdrop-blur-sm">
                            <div class="w-8 h-8 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center text-base shrink-0">
                                📝
                            </div>
                            <div class="min-w-0 flex-1">
                                <h4 class="text-xs font-bold text-white">Streamlined Submissions</h4>
                                <p class="text-[11px] text-slate-400">Automated step-by-step author wizard & live tracking.</p>
                            </div>
                        </div>

                        <div class="flex items-center gap-3 p-2.5 rounded-xl bg-slate-900/60 border border-slate-800/80 backdrop-blur-sm">
                            <div class="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-base shrink-0">
                                ✉️
                            </div>
                            <div class="min-w-0 flex-1">
                                <h4 class="text-xs font-bold text-white">Academic Email & Webmail</h4>
                                <p class="text-[11px] text-slate-400">1-Click cPanel Webmail SSO & in-app messaging.</p>
                            </div>
                        </div>

                        <div class="flex items-center gap-3 p-2.5 rounded-xl bg-slate-900/60 border border-slate-800/80 backdrop-blur-sm">
                            <div class="w-8 h-8 rounded-lg bg-rose-500/20 text-rose-400 flex items-center justify-center text-base shrink-0">
                                🛡️
                            </div>
                            <div class="min-w-0 flex-1">
                                <h4 class="text-xs font-bold text-white">Editorial Integrity</h4>
                                <p class="text-[11px] text-slate-400">Double-blind peer review and Crossref DOI deposits.</p>
                            </div>
                        </div>
                    </div>

                    <!-- Security Note -->
                    <div class="pt-4 flex items-center gap-2 text-[11px] text-slate-500">
                        <svg class="w-4 h-4 text-emerald-500 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                        </svg>
                        <span>256-Bit SSL Encrypted & Protected Institutional Gateway</span>
                    </div>
                </div>

                <!-- Right Column: Interactive Card Wrapper -->
                <div class="w-full lg:col-span-7 max-w-lg mx-auto">
                    <div class="bg-white rounded-3xl p-6 sm:p-10 shadow-2xl border border-slate-200/90 relative overflow-hidden">
                        <slot />
                    </div>
                </div>
            </div>
        </main>

        <!-- Footer Bar -->
        <footer class="relative z-10 w-full py-6 text-center text-xs text-slate-500 border-t border-slate-800/40">
            <p>&copy; {{ new Date().getFullYear() }} Knowledge Dynamics Publishing. All rights reserved. Registered Academic Publisher.</p>
        </footer>
    </div>
</template>
